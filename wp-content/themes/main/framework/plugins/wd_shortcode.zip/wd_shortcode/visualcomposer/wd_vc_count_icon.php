<?php
	// Count Icon
	vc_map(array(
		'name' 				=> esc_html__("Count Icon", 'wpdance'),
		'base' 				=> 'tvlgiao_wpdance_count_icon',
		'description' 		=> esc_html__("Count Icon", 'wpdance'),
		'category' 			=> esc_html__("WPDance", 'wpdance'),
		"params" => array(
			array(
				"type" 			=> "dropdown",
				"class" 		=> "",
				"heading" 		=> esc_html__("Show Icon", 'wpdance'),
				"admin_label" 	=> true,
				"param_name" 	=> "show_icon",
				"value" => array(
						'Yes' 		=> '1',
						'No' 		=> '0'
					),
				"description" 	=> "",
			)
			,array(
				'type' 			=> 'iconpicker',
				'heading' 		=> esc_html__( 'Icon', 'wpdance' ),
				'param_name' 	=> 'icon_fontawesome',
				'value' 		=> 'fa fa-adjust',
				'settings' 		=> array(
					'emptyIcon' 		=> false,
					'iconsPerPage' 		=> 4000,
				),
				'description' 	=> esc_html__( 'Select icon from library.', 'wpdance' ),
			)
			,array(
				"type" 			=> "colorpicker",
				"class" 		=> "",
				"heading" 		=> esc_html__("Color Icon", 'wpdance'),
				"param_name" 	=> "color_icon",
				"value" 		=> "#cccccc",
				"description" 	=> '',
			)
			,array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Start", 'wpdance'),
				'description'	=> esc_html__("", 'wpdance'),
				'admin_label' 	=> true,
				'param_name' 	=> 'start',
				'value' 		=> ''
			)
			,array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Finish", 'wpdance'),
				'description'	=> esc_html__("", 'wpdance'),
				'admin_label' 	=> true,
				'param_name' 	=> 'finish',
				'value' 		=> ''
			)
			,array(
				"type" 			=> "colorpicker",
				"class" 		=> "",
				"heading" 		=> esc_html__("Color Number", 'wpdance'),
				"param_name" 	=> "color_number",
				"value" 		=> "#cccccc",
				"description" 	=> '',
			)
			,array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Text Infomation", 'wpdance'),
				'description'	=> esc_html__("", 'wpdance'),
				'admin_label' 	=> true,
				'param_name' 	=> 'text_infomation',
				'value' 		=> ''
			)
			,array(
				"type" 			=> "colorpicker",
				"class" 		=> "",
				"heading" 		=> esc_html__("Color Text", 'wpdance'),
				"param_name" 	=> "color_text",
				"value" 		=> "#cccccc",
				"description" 	=> '',
			)
			,array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Extra class name", 'wpdance'),
				'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wpdance'),
				'admin_label' 	=> true,
				'param_name' 	=> 'class',
				'value' 		=> ''
			)
		)
	));
?>