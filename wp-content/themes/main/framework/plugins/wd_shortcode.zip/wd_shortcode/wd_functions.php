<?php
// Get Data Chose
if(!function_exists ('tvlgiao_wpdance_vc_get_data')){
	function tvlgiao_wpdance_vc_get_data($array_data){
		global $post;
		$data_array = array();
		$data = new WP_Query($array_data);
		if( $data->have_posts() ){
			while( $data->have_posts() ){
				$data->the_post();
				$data_array[$post->post_title] = $post->ID;
			}
		}
		wp_reset_postdata();
		return $data_array;
	}
}

add_action( 'wp_enqueue_scripts', 'tvlgiao_wpdance_ajax_pagination_scripts' );
function tvlgiao_wpdance_ajax_pagination_scripts() {

 	wp_enqueue_script( 'wd-ajax-pagination-script', plugins_url( '/assets/js/wd_loadmore_js.js', __FILE__ ), array( 'jquery' ) );

 	global $wp_query;
 	wp_localize_script( 'wd-ajax-pagination-script', 'ajax_object', array(
		'ajax_url' 			=> admin_url( 'admin-ajax.php' ),
		'query_vars'		=> json_encode( $wp_query->query )
	));
 	wp_localize_script( 'wd-ajax-pagination-script', 'blog_ajax_object', array(
		'ajax_url_blog' 	=> admin_url( 'admin-ajax.php' ),
		'query_vars'		=> json_encode( $wp_query->query )
	));
 	wp_localize_script( 'wd-ajax-pagination-script', 'masonry_ajax_object', array(
		'ajax_url_masonry' 	=> admin_url( 'admin-ajax.php' ),
		'query_vars'		=> json_encode( $wp_query->query )
	));
}
add_action( 'wp_ajax_load_more', 'load_more_function_post' );
add_action( 'wp_ajax_nopriv_load_more', 'load_more_function_post' );
function load_more_function_post() {
	$query_vars 		= json_decode( stripslashes( $_POST['query_vars'] ), true );
	$offset 			= isset($_REQUEST['offset'])?intval($_REQUEST['offset']):0;
	$posts_per_page 	= isset($_REQUEST['posts_per_page'])?intval($_REQUEST['posts_per_page']):8;
	$post_type 			= isset($_REQUEST['post_type'])?$_REQUEST['post_type']:'post';
	$id_category 		= isset($_REQUEST['category_id'])?$_REQUEST['category_id']:'post';
	$data_show 			= isset($_REQUEST['data_show'])?$_REQUEST['data_show']:'post';

	// New Product
	$args = array( 
		'post_type' 		=> 'product', 
		'offset' 			=> $offset, 
		'posts_per_page' 	=> $posts_per_page,
	);

	//Category
	if( $id_category != -1 ){
		$args['tax_query']= array(
				    	array(
						    	'taxonomy' 		=> 'product_cat',
								'terms' 		=> $id_category,
								'field' 		=> 'term_id',
								'operator' 		=> 'IN'
							)
		   			);
	}
	//Most View Products
	if($data_show == 'mostview_product'){
		$args['meta_key'] 	= '_wd_product_views_count';
		$args['orderby'] 	= 'meta_value_num';
		$args['order'] 		= 'DESC';
	}

	//On Sale Product
	if($data_show == 'onsale_product'){
		$args['meta_query'] = array(
				                    'relation' => 'OR',
				                    array( // Simple products type
				                        'key'           => '_sale_price',
				                        'value'         => 0,
				                        'compare'       => '>',
				                        'type'          => 'numeric'
				                    ),
				                    array( // Variable products type
				                        'key'           => '_min_variation_sale_price',
				                        'value'         => 0,
				                        'compare'       => '>',
				                        'type'          => 'numeric'
				                    )
           					);
	}
	//Featured Product
	if($data_show == 'featured_product'){
		$args['meta_key'] 	= '_featured';
		$args['meta_value'] = 'yes';
	}

	$products = new WP_Query( $args );
	if ( $products->have_posts() ){
		while ( $products->have_posts() ) : $products->the_post(); 
			wc_get_template_part( 'content', 'product' ); 
		endwhile;	 
	}else{ ?>
	    <div id="wd_status" class="hidden">
	    	<input type="text" value="1" id="tvlgiao_have_post">
		</div> <?php
	} // Have Product
	die();
}

add_action( 'wp_ajax_load_more_blog', 'load_more_blog_function_special_post' );
add_action( 'wp_ajax_nopriv_load_more_blog', 'load_more_blog_function_special_post' );
function load_more_blog_function_special_post() {
	$query_vars 		= json_decode( stripslashes( $_POST['query_vars'] ), true );
	$offset 			= isset($_REQUEST['offset'])?intval($_REQUEST['offset']):0;
	$posts_per_page 	= isset($_REQUEST['posts_per_page'])?intval($_REQUEST['posts_per_page']):8;
	$post_type 			= isset($_REQUEST['post_type'])?$_REQUEST['post_type']:'post';
	$id_category 		= isset($_REQUEST['category_id'])?$_REQUEST['category_id']:'post';
	$data_show 			= isset($_REQUEST['data_show'])?$_REQUEST['data_show']:'post';
	$columns			= isset($_REQUEST['columns'])?$_REQUEST['columns']:'post';
	$show_image_slider	= isset($_REQUEST['show_data_image_slider'])?$_REQUEST['show_data_image_slider']:'post';
	$show_gird_list		= isset($_REQUEST['show_gird_list'])?$_REQUEST['show_gird_list']:'post';
	$span_class 		= "col-sm-".(24/$columns);
	wp_reset_query();
	// New blog
	$args = array(  
		'post_type' 		=> 'post',  
		'posts_per_page' 	=> $posts_per_page,
		'offset' 			=> $offset
	);
	//Category
	if( $id_category != -1 ){
		$args['tax_query']= array(
				    	array(
						    	'taxonomy' 		=> 'category',
								'terms' 		=> $id_category,
								'field' 		=> 'term_id',
								'operator' 		=> 'IN'
							)
		   			);
	}
	//Most View Products
	if($data_show == 'mostview_blog'){
		$args['meta_key'] 	= '_wd_post_views_count';
		$args['orderby'] 	= 'meta_value_num';
		$args['order'] 		= 'DESC';
	}
	//Most Comment
	if($data_show == 'comment_blog'){
		$args['orderby']		= 'comment_count';
	}	
	$special_blogs 		= new WP_Query( $args );
	if ( $special_blogs->have_posts() ){
		while ( $special_blogs->have_posts() ) : $special_blogs->the_post();  ?>
			<div class="wd-load-more-content-blog <?php echo esc_attr($span_class);?>">
				<?php if($show_image_slider == "0" && $show_gird_list == "gird" /*GRID*/): ?>
					<?php if( get_post_format() == 'quote'): ?>
						<?php get_template_part( 'content', get_post_format() ); ?>
					<?php else: ?>
						<?php get_template_part( 'content', 'postformat' ); ?>
					<?php endif; ?>
				<?php else: ?>
					<?php get_template_part( 'content', get_post_format() ); ?>
				<?php endif; ?>
			</div>
		<?php endwhile;	
	}else{ ?>
	    <div id="wd_status" class="hidden">
	    	<input type="text" value="1" id="tvlgiao_have_post">
		</div> <?php
	} // Have Product
    die();	
}

add_action( 'wp_ajax_load_more_masonry', 'load_more_masonry_function_special_post' );
add_action( 'wp_ajax_noprivload_more_masonry', 'load_more_masonry_function_special_post' );
function load_more_masonry_function_special_post() {
	$query_vars 		= json_decode( stripslashes( $_POST['query_vars'] ), true );
	$offset 			= isset($_REQUEST['offset'])?intval($_REQUEST['offset']):0;
	/*$posts_per_page 	= isset($_REQUEST['posts_per_page'])?intval($_REQUEST['posts_per_page']):8;
	$post_type 			= isset($_REQUEST['post_type'])?$_REQUEST['post_type']:'post';
	$id_category 		= isset($_REQUEST['category_id'])?$_REQUEST['category_id']:'post';
	$data_show 			= isset($_REQUEST['data_show'])?$_REQUEST['data_show']:'post';
	$columns			= isset($_REQUEST['columns'])?$_REQUEST['columns']:'post';
	$show_image_slider	= isset($_REQUEST['show_data_image_slider'])?$_REQUEST['show_data_image_slider']:'post';
	$show_gird_list		= isset($_REQUEST['show_gird_list'])?$_REQUEST['show_gird_list']:'post';*/
	$columns			= 4;
	$span_class 		= "col-sm-".(24/$columns);
	
	wp_reset_query();
	$args = array(		
		'post_type' 		=> 'post',
		'posts_per_page' 	=> 4 ,
		'offset' 			=> $offset
	);
	$masonry_blogs 		= new WP_Query( $args );
	
	if ( $masonry_blogs->have_posts() ){
		while ( $masonry_blogs->have_posts() ) : $masonry_blogs->the_post();  ?>
			<div class="wd-item-blog <?php echo esc_attr($span_class);?>">
				<?php if( get_post_format() == 'quote'): ?>
					<?php get_template_part( 'content', get_post_format() ); ?>
				<?php else: ?>
					<?php get_template_part( 'content', 'postformat' ); ?>
				<?php endif; ?>
			</div>
		<?php endwhile;	
	}else{ ?>
	    <div id="wd_status" class="hidden">
	    	<input type="text" value="1" id="tvlgiao_have_post">
		</div> <?php
	} // Have Product
    die();	
}


// AJAX
add_action('wp_ajax_nopriv_more_post_ajax', 'tvlgiao_wpdance_more_post_ajax'); 
add_action('wp_ajax_more_post_ajax', 'tvlgiao_wpdance_more_post_ajax');
function tvlgiao_wpdance_more_post_ajax(){ 
	global $wp_outline_wd_data;

	$offset 		= $_POST["offset"];
	$posts_per_page = $_POST["posts_per_page"];
	$columns 		= $_POST["columns"];
	header("Content-Type: text/html");

	wp_reset_postdata();
	$args = array(		
		'post_type' 				=> 'post'
		,'posts_per_page' 			=> $posts_per_page
		,'offset' 					=> $offset
		,'ignore_sticky_posts' 		=> 1
	);
	$posts = new WP_Query($args);
	$span_class = "col-sm-".(24/$columns);
	if( $posts->have_posts() ) { ?>
		<?php $wd_have_post = 1; ?>
		<?php while ( $posts->have_posts() ) : $posts->the_post(); global $post; ?>
			<div class="wd-wrap-content-blog grid-item <?php echo esc_attr($span_class); ?>">
	        	<?php get_template_part( 'content','masonry' ); ?>
	        </div>
		<?php endwhile;   ?>
	<?php }else{ ?>
	<?php $wd_have_post = 0;?>
	<?php }; ?>
	<div id="wd_status" class="hidden">
		<input type="text" value="<?php echo esc_html( $wd_have_post); ?>" id="wp_outline_have_post">
	</div>
	<?php exit; ?>
<?php } 
?>